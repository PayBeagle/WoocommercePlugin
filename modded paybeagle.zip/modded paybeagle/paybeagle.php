<?php
/*
 * Plugin Name: Appletree's Paybeagle For WooCommerce
 * Description: Appletree's paybeale payment gateway accept card payment using iframe and redirect method.
 * Author: Sunny Kasera, sunny.kasera@webintellizer.com
 * Author URI: https://www.webintellizer.com
 * Version: 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Check if WooCommerce is active
 **/
if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
	add_action('plugins_loaded', 'woocommerce_gateway_pabeagle_init', 0);

	function woocommerce_gateway_pabeagle_init() {
		if ( !class_exists( 'WC_Payment_Gateway' ) ) return;

		/**
		 * Payeagle Payment Gateway class
		 * 
		 * WC_paybeagle_Gateway is a woocomerce based payment gateway class extending core class WC_Payment_gateway
		 *
		 * @see WC_Payment_Gateway relied on
		 * @link https://docs.woocommerce.com/wc-apidocs/class-WC_Payment_Gateway.html
		 **/

		class WC_paybeagle_Gateway extends WC_Payment_Gateway {

			public function __construct(){
				$this->id = 'paybeagle'; // payment gateway plugin ID
				$this->icon = plugins_url( '/paybeagle/images/proud-beagle-logo.png', dirname(__FILE__) ); // URL of the icon that will be displayed on checkout page near your gateway name
				$this->has_fields = false; // in case you need a custom credit card form
				$this->method_title = __('Appletree\'s Paybeagle');
				$this->method_description = __('Appletree\'s paybeagle payment gateway for woocommerce'); // will be displayed on the options page
				// gateways can support subscriptions, refunds, saved payment methods
				$this->supports = array(
					'products'
				);
				// Method with all the options fields
				$this->init_form_fields();
				// Load the settings.
				$this->init_settings();				
				$this->title = __($this->get_option( 'title' ));
				$this->description = __($this->get_option( 'description' ));
				$this->enabled = $this->get_option( 'enabled' );
				$this->testmode = 'yes' === $this->get_option( 'testmode' );
				$this->test_private_key = $this->get_option( 'test_merchant_user' );
				$this->test_publishable_key = $this->get_option( 'test_password_key' );
				$this->live_private_key = $this->get_option( 'live_merchant_user' );
				$this->live_publishable_key = $this->get_option( 'live_password_key' );
				//save admin options:		
				add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );	
				add_action('woocommerce_receipt_'.$this->id, array($this, 'woocommerce_receipt_page'));
				add_action('woocommerce_thankyou_'.$this->id, array($this, 'woocommerce_thankyou_page'));
				add_action( 'woocommerce_api_'.$this->id, array( $this, 'webhook' ),20 );
			}

			/**
			 * Initialise settings form fields.
			 *
			 * Add an array of fields to be displayed on the gateway's settings screen.
			 *
			 */
			public function init_form_fields(){
			    $home_url = get_home_url();
				$this->form_fields = array(
					'information' => array(
					 	'title'			=>	__('URL Information'),
						'type'			=>	'textarea',
						'description'	=>	__('Put these urls in your Appletree\'s Account'),
						'default'		=>	'Return URL : '.$home_url.'/checkout/order-received/[[REF]]                   
Error URL : '.$home_url.'/checkout/[[REF]]                                                         
IPN URL : '.$home_url.'/wc-api/paybeagle?id=[[REF]]',
				        'custom_attributes' => array('readonly' => 'readonly'), // Enabling read only
					),
					'enabled' => array(
						'title'			=>	__('Enable/Disable'),
						'label'			=>	__('Enable Appletree\'s Paybeagle Gateway'),
						'type'			=>	'checkbox',
						'description'	=>	'',
						'default'		=>	'no'
					),
					'title' => array(
						'title'			=>	__('Title'),
						'type'			=>	'text',
						'description'	=>	__('This controls the title which the user sees during checkout.'),
						'default'		=>	'Paybeagle Method',
						'desc_tip'		=>	true,
					),
					'description' => array(
						'title'			=>	__('Description'),
						'type'			=>	'textarea',
						'description'	=>	__('This controls the description which the user sees during checkout.'),
						'default'		=>	'Pay with your credit card via paybeagle payment gateway.',
						'desc_tip'		=>	true,
					),
					'testmode' => array(
						'title'			=>	__('Test mode'),
						'label'			=>	__('Enable Test Mode'),
						'type'			=>	'checkbox',
						'description'	=>	'',
						'default'		=>	'yes',
						'desc_tip'		=>	true,
					),
					'test_merchant_user'=> array(
						'title'			=>	__('Test Merchant User'),
						'type'			=>	'text'
					),
					'test_password_key'	=> array(
						'title'			=>	__('Test Password'),
						'type'			=>	'password'
					),
					'live_merchant_user'=> array(
						'title'			=>	__('Live Merchant User'),
						'type'			=>	'text'
					),
					'live_password_key'	=> array(
						'title'			=>	__('Live Password'),
						'type'			=>	'password'
					),
					'paybeagle-iframe-mode' => array(
						'title' 		=> __('PayBeagle Iframe Mode'),
						'type'			=> 'checkbox',
						'default' 		=> 'disable',
						'description'	=> __('Integration Mode. Disable this option for REDIRECT Enable for IFRAME.')
					)
				);
			}

			/**
			 * If There are no payment fields show the description if set.
			 * Override this in your gateway if you have some.
			 */	
			public function payment_fields(){
				echo __($this->description);
			}

			/**
			 * Preparing to Payment window
			 *
			 * @access public
			 * @param int $order_id
			 */
			public function woocommerce_receipt_page( $order_id ) {
				global $woocommerce;
				$order = new WC_Order($order_id);
				
				$f = fopen("ipnres3.txt", "a");
                fwrite($f, print_r($_REQUEST, true));
                fwrite($f, print_r($_POST, true));
                fclose($f);
				
				$transactionResult = trim($_POST['transactionResult']);
				
				$order_status = $order->get_status();
				if (!empty($_POST['payBeagleTransactionRef'])){
					if ($transactionResult == 'Payment processed successfully' || $transactionResult == 'Payment Processed Sucessfully' || $transactionResult == '[3DS] - Order Is Authorized' || strpos($transactionResult, 'Order Is Authorized') !== false) {
						if($order_status != 'wc-completed'){
							$order->update_status('wc-processing', "Your order is Processing");
						}
					}else{
						$order->update_status( 'wc-failed', $transactionResult.' Failed To Validate Transaction.' );
					}
					$order_key = $order->get_order_key();
					$order_ref = $order_id.'/?key='.$order_key;
					$home_url = get_home_url();
					$return_url = $home_url.'/checkout/order-received/'.$order_ref.'&';
					wp_redirect( $return_url );
					exit;
				}
				
				$order_id = $order->get_id();
				$order_key = $order->get_order_key();
				$paybeagle_sandbox = $this->get_option("testmode");
				if( $paybeagle_sandbox == 'yes'){
					$paybeagle_url = "https://sandboxx.paybeagle.com/static/hosted.js";
					$merchant_user = $this->get_option("test_merchant_user");
					$merchant_key = $this->get_option("test_password_key");
				}else{
					$paybeagle_url = "https://secure.paybeagle.com/static/hosted.js";	
					$merchant_user = $this->get_option("live_merchant_user");
					$merchant_key = $this->get_option("live_password_key");
				}
				$iframe_mode = $this->get_option('paybeagle-iframe-mode');
				if( empty($iframe_mode) || $iframe_mode == 'disable'|| $iframe_mode == 'no' ){
					$integration_type = "REDIRECT";
				}else{
					$integration_type = "IFRAME";	
				}
				if ( function_exists('wpml_object_id') ) {
					$language_code = apply_filters( 'wpml_current_language', NULL );
				}else{
					$language_code = 'en';
				}
				$order_ref = $order_id.'/?key='.$order_key;
				$amount = empty($woocommerce->cart->total) ? $order->get_total() : $woocommerce->cart->total;
				$amount = number_format((float)$amount, 2, '.', '');
				
				$description = __("Online purchase #".$order_id);
				$cardForm = '<script type="text/javascript" src="'.$paybeagle_url.'"></script>';
				$cardForm .= '<div id="payBeagleHostedPlugin"></div>';
				$cardForm .= "<script type='text/javascript'>
								(function($){
									$(document).ready(function() { 
										var payment = new PayBeagle({
											'type':'".$integration_type."',
											'userID':'".$merchant_user."',
											'userPassword':'".$merchant_key."',
											'amount':'".$amount."',
											'orderRef':'".$order_ref."',
											'orderDescription' : '".$description."',
											'metadata'	: '',
											'language': '".$language_code."'
										});
										payment.execute();
									});
								})(jQuery);									
							  </script>";
				echo $cardForm;
			}

			/**
			 * Process the payment and return the result
			 *
			 * @access public
			 * @param int $order_id
			 * @return array
			 */
			public function process_payment( $order_id ) {
				global $woocommerce;
				$order = new WC_Order($order_id);

				return array(
					'result' => 'success',
					'redirect' => $order->get_checkout_payment_url( true )
				);
			}

			/**
			 * Returning back to response page
			 *
			 * @access public
			 * @param int $order_id
			 */
			public function woocommerce_thankyou_page($order_id){
				$order = new WC_Order($order_id);
				$order_status = $order->get_status();
				
				$f = fopen("ipnres2.txt", "a");
                fwrite($f, print_r($_REQUEST, true));
                fwrite($f, print_r($_POST, true));
                fclose($f);
				
				$transactionResult = trim($_POST['transactionResult']);
				
				if (!empty($_POST['payBeagleTransactionRef'])){
					if ($transactionResult == 'Payment processed successfully' || $transactionResult == 'Payment Processed Sucessfully' || $transactionResult == '[3DS] - Order Is Authorized' || strpos($transactionResult, 'Order Is Authorized') !== false) {
						if($order_status != 'wc-completed'){
							$order->update_status('wc-processing', "Your order is Processing");
						}
					}else{
						$order->update_status( 'wc-failed', $transactionResult.' Failed To Validate Transaction.' );
					}
				// 	$order_key = $order->get_order_key();
				// 	$order_ref = $order_id.'/?key='.$order_key;
				// 	$home_url = get_home_url();
				// 	$return_url = $home_url.'/checkout/order-received/'.$order_ref.'&';
				// 	wp_redirect( $return_url );
				// 	exit;
				}
			}

			/**
			 * Recieving Payment Notification
			 *
			 * @access public
			 *
			 */
			public function webhook() {
				global $woocommerce;
                $f = fopen("ipnres1.txt", "a");
                fwrite($f, print_r($_REQUEST, true));
                fwrite($f, print_r($_SERVER, true));
                fwrite($f, print_r($_POST, true));
                fclose($f);
				if(isset($_REQUEST['id']) && !empty($_REQUEST['id'])){
					$strip_id = $_REQUEST['id'];
					$explode_id = explode('/?key=', $strip_id);
					$order_id = $explode_id[0];
					$order_key = $explode_id[1];

					$IPN = isset($_POST['validationToken']) ? $_POST['validationToken'] : '';
					$paybeagle_sandbox = $this->get_option("testmode");
					if( $paybeagle_sandbox == 'yes'){
						$paybeagle_url = "https://sandboxx.paybeagle.com/ipn/".$IPN;
					}else{
						$paybeagle_url = "https://secure.paybeagle.com/ipn/".$IPN;
					}
					// Check If the notification is Valid or Not
					if($this->validateTransaction($paybeagle_url, $_POST)){
						$transactionResult = trim($_POST['transactionResult']);
						$order = new WC_Order($order_id);
						$order_status = $order->get_status();
						
						$f = fopen("ipnres1.txt", "a");
						fwrite($f, $order_status, true);
						fclose($f);
						
						if ($transactionResult == 'Payment Processed Successfully' || $transactionResult == 'Payment Processed Sucessfully' || $transactionResult == '[3DS] - Order Is Authorized' || strpos($transactionResult, 'Order Is Authorized') !== false) {
							if($order_status != 'wc-processing'){
								$order->update_status('wc-processing', "Your order is Processing");
							}
							$order->update_status( 'wc-completed', $transactionResult.' Transaction Validated.' );
						}else{
							$order->update_status( 'wc-failed', $transactionResult.' Failed To Validate Transaction.' );	
						}
					}
				}
			}

			/**
			 * Validate if a transaction is Valid or Not
			 */
			private function validateTransaction($URL, $data){
				$ch = curl_init($URL);
				curl_setopt($ch, CURLOPT_HEADER, true);
				curl_setopt($ch, CURLOPT_NOBODY, true);
				curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
				curl_setopt($ch, CURLOPT_TIMEOUT,10);
				curl_setopt($ch, CURLOPT_POST, true);
				curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
				$output = curl_exec($ch);
				$HTTPcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
				if($HTTPcode == 200){
					return true;
				}
			}

		}
		
		/**
		 * Add the Gateway to WooCommerce
		 */
		function woocommerce_add_gateway_paybeagle($methods) {
			$methods[] = 'WC_paybeagle_Gateway';
			return $methods;
		}
		
		add_filter('woocommerce_payment_gateways', 'woocommerce_add_gateway_paybeagle' );
	}

}